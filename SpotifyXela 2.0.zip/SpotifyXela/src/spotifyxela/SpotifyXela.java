
package spotifyxela;
import spotifyxela.newpackage.mainGui;

public class SpotifyXela {

    public static void main(String[] args) {
      //frame principal
      mainGui fp = new mainGui();
      fp.setVisible(true);
      fp.setLocationRelativeTo(null);
      fp.setExtendedState(mainGui.MAXIMIZED_BOTH);

    }
    
}
