
package spotifyxela;

import spotifyxela.newpackage.mainGUI;

public class SpotifyXela {

    public static void main(String[] args) {
      mainGUI fp = new mainGUI();
      fp.setVisible(true);
      fp.setLocationRelativeTo(null);
      fp.setExtendedState(mainGUI.MAXIMIZED_BOTH);
    }
    
}
