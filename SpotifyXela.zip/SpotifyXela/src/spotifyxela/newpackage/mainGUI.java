package spotifyxela.newpackage;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JPanel;


public class mainGUI extends javax.swing.JFrame {

   
    public mainGUI() {
       initComponents();
       configurarCentrado();
       setExtendedState(mainGUI.MAXIMIZED_BOTH);
    
    }
    
       private void configurarCentrado() {
        // Crear un panel para centrar el botón y el campo de texto
        JPanel panelCentrado = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        
        // Configurar el tamaño preferido del campo de texto
        jTextField1.setPreferredSize(new Dimension(400, 30));

        // Configurar el tamaño preferido del panel Historial
        Historial.setPreferredSize(new Dimension(getWidth(), 200));

        // Agregar el botón y el campo de texto al panel centrado
        panelCentrado.add(btnHome);
        panelCentrado.add(jTextField1);

        // Configurar el layout del JFrame y agregar los paneles
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelCentrado, BorderLayout.NORTH); // Colocar el panel centrado en la parte superior
        getContentPane().add(Historial, BorderLayout.CENTER); // Colocar Historial en el centro

        this.pack();
        this.setLocationRelativeTo(null);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnHome = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Historial = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnHome.setText("HOME");
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setText("¿Que quieres reproducir?");

        javax.swing.GroupLayout HistorialLayout = new javax.swing.GroupLayout(Historial);
        Historial.setLayout(HistorialLayout);
        HistorialLayout.setHorizontalGroup(
            HistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 923, Short.MAX_VALUE)
        );
        HistorialLayout.setVerticalGroup(
            HistorialLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(268, 268, 268)
                .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Historial, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(Historial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(288, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHomeActionPerformed
      HISTORIAL hs = new HISTORIAL();
      hs.setSize(getWidth(),200);
      hs.setLocation(0, 0);

      Historial.removeAll();
      Historial.add(hs, BorderLayout.CENTER);
      Historial.revalidate();
      Historial.repaint();
    }//GEN-LAST:event_btnHomeActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Historial;
    private javax.swing.JButton btnHome;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
